package baseballgame;

public class InputException extends IllegalArgumentException{

    public InputException(String message){
        super(message);
    }
    /*
        커스텀 예외를 만들어주었군요! 💯 💯
        하나 고민해볼것이 있어요.
        커스텀 예외를 사용하면 좋은점이 무엇일까요?
     */
}
